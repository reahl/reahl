from reahl.dev.pytestmonkeypatch import apply_patch_for


apply_patch_for(__file__)
