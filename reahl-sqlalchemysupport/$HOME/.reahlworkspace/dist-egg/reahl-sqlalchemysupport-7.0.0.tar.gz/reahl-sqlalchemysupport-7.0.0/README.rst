 Reahl is a web application framework that allows a Python programmer to work in 
 terms of useful abstractions - using a single programming language.

 This package contains infrastructure necessary to
 use Reahl with SqlAlchemy or Elixir.
